package aplicacion;

import presentacion.InterfazUsuario;

public class Principal{
	public static void main(String[] args){
		InterfazUsuario.ejecutar(args);
	}
}
